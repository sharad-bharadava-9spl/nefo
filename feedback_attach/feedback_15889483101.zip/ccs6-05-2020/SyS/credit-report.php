<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/view.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';

	$accessLevel = '3';
	
	// Authenticate & authorize
	authorizeUser($accessLevel);

	require_once 'PHPExcel/Classes/PHPExcel.php';

	// Create new PHPExcel object
	$objPHPExcel = new PHPExcel();
	// Set document properties
	$objPHPExcel->getProperties()->setCreator("Lokesh Nayak")
	                             ->setLastModifiedBy("Lokesh Nayak")
	                             ->setTitle("Test Document")
	                             ->setSubject("Test Document")
	                             ->setDescription("Test document for PHPExcel")
	                             ->setKeywords("office")
	                             ->setCategory("Test result file");	

	// Query to look up users
	$selectUsers = "SELECT distinct family, credit FROM users";
		try
		{
			$results = $pdo3->prepare("$selectUsers");
			$results->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	


	  				$objPHPExcel->setActiveSheetIndex(0);
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('A1',$lang['member-firstnames']);
					$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);  
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('B1',$lang['member-lastnames']);
					$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);  		
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('C1',$lang['global-credit']);
					$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);  
					
$startIndex = 2;
  $total_count = $results->rowCOunt();
	while ($user = $results->fetch()) {
	
	// Calculate Age:
	$family = $user['family'];
	$credit = $user['credit'];
	$totCredit = $totCredit + $credit;
	
	$parents = "SELECT user_id, first_name, last_name FROM users WHERE family = $family ORDER by userGroup ASC";
		try
		{
			$result = $pdo3->prepare("$parents");
			$result->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		$row = $result->fetch();
		$user_id = $row['user_id'];
		$first_name = $row['first_name'];
		$last_name = $row['last_name'];
		
	/*echo sprintf("
  	  <tr>
  	   <td class='clickableRow left' href='family.php?user_id=%d'>%s</td>
  	   <td class='clickableRow left' href='family.php?user_id=%d'>%s</td>
  	   <td class='clickableRow right' href='family.php?user_id=%d'>%0.2f &euro;</td>",
	  $user_id, $first_name, $user_id, $last_name, $user_id, $credit);*/

	 	   $objPHPExcel->getActiveSheet()
		                ->setCellValue('A'.$startIndex, $first_name);
		    $objPHPExcel->getActiveSheet()
		                ->setCellValue('B'.$startIndex, $last_name);
		    $objPHPExcel->getActiveSheet()
		                ->setCellValue('C'.$startIndex,  $credit." €");

	$startIndex++;
	  
  	}
  	$lastIndex = $total_count + 1;
  	$objPHPExcel->getActiveSheet()
	            ->setCellValue('A'.$lastIndex,'TOTAL:');
	$objPHPExcel->getActiveSheet()->getStyle('A'.$lastIndex)->getFont()->setBold(true);  
	$objPHPExcel->getActiveSheet()
	            ->setCellValue('C'.$lastIndex,$totCredit." €");
	$objPHPExcel->getActiveSheet()->getStyle('C'.$lastIndex)->getFont()->setBold(true); 
  	/*echo sprintf("<tr><td class='left' colspan='2'><strong>TOTAL:</strong></td><td class='right'><strong>%0.2f &euro;</strong></td></tr>", $totCredit);*/
	ob_end_clean();

     $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header("Content-Disposition: attachment;filename=credit.xlsx");
	header('Cache-Control: max-age=0');
	header("Content-Type: application/download");
	$objWriter->save('php://output');
   
	die;

