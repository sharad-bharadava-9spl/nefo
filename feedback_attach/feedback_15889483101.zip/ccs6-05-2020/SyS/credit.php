<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/view.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';
	
	session_start();

	$accessLevel = '3';
	
	// Authenticate & authorize
	authorizeUser($accessLevel);
	
	// Query to look up users
	$selectUsers = "SELECT distinct family, credit FROM users";
		try
		{
			$results = $pdo3->prepare("$selectUsers");
			$results->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		
	$memberScript = <<<EOD
	
	    $(document).ready(function() {
		    
		    
			$("#xllink").click(function(){

			  $("#mainTable").table2excel({
			    // exclude CSS class
			    exclude: ".noExl",
			    name: "Socios",
			    filename: "Socios" //do not include extension
		
			  });
		
			});
		    
		    
		    
			$('#cloneTable').width($('#mainTable').width());
			
			$.tablesorter.addParser({
			  id: 'dates',
			  is: function(s) { return false },
			  format: function(s) {
			    var dateArray = s.split('-');
			    return dateArray[2].substring(0,4) + dateArray[1] + dateArray[0];
			  },
			  type: 'numeric'
			});
			
			
			$('#mainTable').tablesorter({
				usNumberFormat: true,
				headers: {
					2: {
						sorter: "currency"
					}
				}
			}); 

		
		});
		
		$(window).resize(function() {
			$('#cloneTable').width($('#mainTable').width());
		});
		
EOD;


	pageStart("Students", NULL, $memberScript, "pmembership", NULL, "STUDENTS", $_SESSION['successMessage'], $_SESSION['errorMessage']);
?>
	 <table class='default' id='cloneTable'>
      <tr class='nonhover'>
       <td colspan='13' style='border-bottom: 0;'>
         <a href="#" onClick="loadExcel();"><img src="images/excel.png" style='margin: 0 0 -5px 8px;'/></a>
       </td>
      </tr>
     </table>
<br />
	 <table class='default' id='mainTable'>
	  <thead>	
	   <tr style='cursor: pointer;'>
	    <th><?php echo $lang['member-firstnames']; ?></th>
	    <th><?php echo $lang['member-lastnames']; ?></th>
	    <th><?php echo $lang['global-credit']; ?></th>
	   </tr>
	  </thead>
	  <tbody>
	  
	  <?php

		while ($user = $results->fetch()) {
	
	// Calculate Age:
	$family = $user['family'];
	$credit = $user['credit'];
	$totCredit = $totCredit + $credit;
	
	$parents = "SELECT user_id, first_name, last_name FROM users WHERE family = $family ORDER by userGroup ASC";
		try
		{
			$result = $pdo3->prepare("$parents");
			$result->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		$row = $result->fetch();
		$user_id = $row['user_id'];
		$first_name = $row['first_name'];
		$last_name = $row['last_name'];
		
	echo sprintf("
  	  <tr>
  	   <td class='clickableRow left' href='family.php?user_id=%d'>%s</td>
  	   <td class='clickableRow left' href='family.php?user_id=%d'>%s</td>
  	   <td class='clickableRow right' href='family.php?user_id=%d'>%0.2f &euro;</td>",
	  $user_id, $first_name, $user_id, $last_name, $user_id, $credit);
	  
  	}
  	
  	echo sprintf("<tr><td class='left' colspan='2'><strong>TOTAL:</strong></td><td class='right'><strong>%0.2f &euro;</strong></td></tr>", $totCredit);
?>

	 </tbody>
	 </table>

<?php  displayFooter(); ?>
<script type="text/javascript">
	 function loadExcel(){
 			$("#load").show();
       		window.location.href = 'credit-report.php';
       		    setTimeout(function () {
			        $("#load").hide();
			    }, 5000);   
       }
</script>
