<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/view.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';
	
	session_start();
	$accessLevel = '3';
	
	// Authenticate & authorize
	authorizeUser($accessLevel);
	require_once 'PHPExcel/Classes/PHPExcel.php';

	// Create new PHPExcel object
	$objPHPExcel = new PHPExcel();
	// Set document properties
	$objPHPExcel->getProperties()->setCreator("Lokesh Nayak")
	                             ->setLastModifiedBy("Lokesh Nayak")
	                             ->setTitle("Test Document")
	                             ->setSubject("Test Document")
	                             ->setDescription("Test document for PHPExcel")
	                             ->setKeywords("office")
	                             ->setCategory("Test result file");	
	// Query to look up users
	$selectUsers = "SELECT u.user_id, u.memberno, u.first_name, u.last_name, u.registeredSince, u.dni, u.gender, u.day, u.month, u.year, u.doorAccess, u.paidUntil, u.userGroup, ug.groupName, ug.groupDesc, u.form1, u.form2, u.credit, u.usageType, u.creditEligible, u.dniscan, u.dniext1, u.starCat, u.yearGroup, u.form, u.fptemplate1, u.parent, u.nationality, u.photoext, u.staffCat, u.family FROM users u, usergroups ug WHERE u.userGroup = ug.userGroup AND u.userGroup = 5 ORDER by u.last_name ASC";
	try
	{
		$results = $pdo3->prepare("$selectUsers");
		$results->execute();
	}
	catch (PDOException $e)
	{
			$error = 'Error fetching user: ' . $e->getMessage();
			echo $error;
			exit();
	}


	  				$objPHPExcel->setActiveSheetIndex(0);
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('A1',$lang['global-name']);
					$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);  
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('B1',$lang['member-lastnames']);
					$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);  		
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('C1',$lang['global-credit']);
					$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('D1',$lang['member-gender']);
					$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('E1',$lang['age']);
					$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('F1','Group');
					$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('G1','Category');
					$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('H1','Fingerprint');
					$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('I1','Photo');
					$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('J1','Portal');
					$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true); 
	$startIndex =2;				
	while ($user = $results->fetch()) {
	
	// Calculate Age:
	$day = $user['day'];
	$month = $user['month'];
	$year = $user['year'];	
	$fptemplate1 = $user['fptemplate1'];	
	$family = $user['family'];	
	
	$bdayraw = $day . "." . $month . "." . $year;
	$bday = new DateTime($bdayraw);
	$today = new DateTime(); // for testing purposes
	$diff = $today->diff($bday);
	$age = $diff->y;

	// Find out if member has registered fingerprint:
	if ($fptemplate1 == '') {
		$form1colour = 'negative';
		$form1 = $lang['global-no'];
	} else {
		$form1colour = '';
		$form1 = $lang['global-yes'];
	}
	
	// Find out if photo has been taken
	$file = 'images/members/' . $user['user_id'] . '.' . $user['photoext'];
	
	if (!file_exists($file)) {
		$dnicolour = 'negative';
		$dniScan = $lang['global-no'];
	} else {
		$dnicolour = '';
		$dniScan = $lang['global-yes'];
	}

	// Find out if member has registered parent(s):
	if ($parent == 0) {
		$form2colour = 'negative';
		$form2 = $parent;
	} else {
		$form2colour = '';
		$form2 = $parent;
	}
	
	// Does user have comments?
	$getNotes = "SELECT noteid, notetime, userid, note FROM usernotes WHERE userid = {$user['user_id']} ORDER by notetime DESC";
	try
	{
		$result = $pdo3->prepare("$getNotes");
		$result->execute();
		$data = $result->fetchAll();
	}
	catch (PDOException $e)
	{
			$error = 'Error fetching user: ' . $e->getMessage();
			echo $error;
			exit();
	}
		
	if (!$data) {
   		$comment = '';
	} else {
   		$comment = "<img src='images/note.png' width='16' /><span style='display:none'>1</span>";
	}
	
	$parents = "SELECT userPass FROM users WHERE family = $family AND userGroup <> 4";
		try
		{
			$results2 = $pdo3->prepare("$parents");
			$results2->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
		
	$portal = 0;
		
		while ($check = $results2->fetch()) {
		
		$userPass = $check['userPass'];
		
		if ($userPass != NULL) {
			
			$portal = 1;
			
		}
		
	}
	
	if ($portal == 0) {
		$portalcolour = 'negative';
		$portal = $lang['global-no'];
	} else {
		$portalcolour = '';
		$portal = $lang['global-yes'];
	}
	

	  
	 	   $objPHPExcel->getActiveSheet()
		                ->setCellValue('A'.$startIndex, $user['first_name']);
		    $objPHPExcel->getActiveSheet()
		                ->setCellValue('B'.$startIndex, $user['last_name']);
		    $objPHPExcel->getActiveSheet()
		                ->setCellValue('C'.$startIndex,  $user['credit']." €");
		    $objPHPExcel->getActiveSheet()
		                ->setCellValue('D'.$startIndex, $user['gender']); 
            $objPHPExcel->getActiveSheet()
            			->setCellValue('E'.$startIndex, $age); 
            $objPHPExcel->getActiveSheet()
           				 ->setCellValue('F'.$startIndex, $user['groupName']);  
            $objPHPExcel->getActiveSheet()
           				 ->setCellValue('G'.$startIndex, $user['staffCat']);  
           $objPHPExcel->getActiveSheet()
           				 ->setCellValue('H'.$startIndex, $form1);  
           $objPHPExcel->getActiveSheet()
           				 ->setCellValue('I'.$startIndex, $dniScan); 
           $objPHPExcel->getActiveSheet()
           				 ->setCellValue('J'.$startIndex, $portal); 

	  $startIndex++;
  	}

	ob_end_clean();

     $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header("Content-Disposition: attachment;filename=parents.xlsx");
	header('Cache-Control: max-age=0');
	header("Content-Type: application/download");
	$objWriter->save('php://output');
die;
?>

	
