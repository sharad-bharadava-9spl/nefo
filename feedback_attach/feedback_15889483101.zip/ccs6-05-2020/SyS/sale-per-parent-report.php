<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/view.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';
	
	session_start();
	$accessLevel = '1';
	
	// Authenticate & authorize
	authorizeUser($accessLevel);
	require_once 'PHPExcel/Classes/PHPExcel.php';

	// Create new PHPExcel object
	$objPHPExcel = new PHPExcel();
	// Set document properties
	$objPHPExcel->getProperties()->setCreator("Lokesh Nayak")
	                             ->setLastModifiedBy("Lokesh Nayak")
	                             ->setTitle("Test Document")
	                             ->setSubject("Test Document")
	                             ->setDescription("Test document for PHPExcel")
	                             ->setKeywords("office")
	                             ->setCategory("Test result file");	
	
	// Query to look up users
	$selectUsers = "SELECT u.user_id, u.memberno, u.first_name, u.last_name, u.registeredSince, u.dni, u.gender, u.day, u.month, u.year, u.doorAccess, u.paidUntil, u.userGroup, ug.groupName, ug.groupDesc, u.form1, u.form2, u.credit, u.usageType, u.creditEligible, u.dniscan, u.dniext1, u.family FROM users u, usergroups ug WHERE u.userGroup = ug.userGroup AND u.userGroup <> 4 ORDER by u.last_name ASC";
		try
		{
			$results = $pdo3->prepare("$selectUsers");
			$results->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
	
?>
	  
	  <?php

	  	$objPHPExcel->setActiveSheetIndex(0);
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('A1',$lang['global-name']);
					$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);  
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('B1',$lang['member-lastnames']);
					$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);  		
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('C1','Group');
					$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('D1','Bocadillo');
					$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('E1','SnackShack');
					$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true); 
					$objPHPExcel->getActiveSheet()
					            ->setCellValue('F1','Total');
					$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true); 
					
  $startIndex =2;
		while ($user = $results->fetch()) {
	
	$family = $user['family'];
	
	$emailQuery = "SELECT user_id FROM users WHERE family = $family";
		try
		{
			$results2 = $pdo3->prepare("$emailQuery");
			$results2->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		
	$familyIDs = '';
		
		while ($rowU = $results2->fetch()) {
		
		$uid = $rowU['user_id'];
		
		$familyIDs .= "$uid, ";
		
	}
	
	$familyTrimmed = substr($familyIDs, 0, -2);
		
	// Look up bocadillo sales
	$selectSales = "SELECT SUM(amount) from sales WHERE userid IN ($familyTrimmed)";
		try
		{
			$result = $pdo3->prepare("$selectSales");
			$result->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		$row = $result->fetch();
		$salesToday = $row['SUM(amount)'];
	
	// Look up snackshack sales
	$selectb_sales = "SELECT SUM(amount) from b_sales WHERE userid IN ($familyTrimmed)";
		try
		{
			$result = $pdo3->prepare("$selectb_sales");
			$result->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		$row = $result->fetch();
		$b_salesToday = $row['SUM(amount)'];
		
	$totSales = $salesToday + $b_salesToday;
	
	
/*	echo sprintf("
  	  <tr>
  	   <td class='clickableRow' href='profile.php?user_id=%d'>%s</td>
  	   <td class='clickableRow' href='profile.php?user_id=%d'>%s</td>
  	   <td class='clickableRow' href='profile.php?user_id=%d'>%s</td>
  	   <td class='clickableRow right' href='profile.php?user_id=%d'>%0.2f &euro;</td>
  	   <td class='clickableRow right' href='profile.php?user_id=%d'>%0.2f &euro;</td>
  	   <td class='clickableRow right' href='profile.php?user_id=%d'><strong>%0.2f &euro;</strong></td></tr>",
	  $user['user_id'], $user['first_name'], $user['user_id'], $user['last_name'], $user['user_id'], $user['groupName'], $user['user_id'], $salesToday, $user['user_id'], $b_salesToday, $user['user_id'], $totSales);*/

	 	   $objPHPExcel->getActiveSheet()
		                ->setCellValue('A'.$startIndex, $user['first_name']);
		    $objPHPExcel->getActiveSheet()
		                ->setCellValue('B'.$startIndex, $user['last_name']);
		    $objPHPExcel->getActiveSheet()
		                ->setCellValue('C'.$startIndex,  $user['groupName']);
		    $objPHPExcel->getActiveSheet()
		                ->setCellValue('D'.$startIndex, $salesToday." €"); 
            $objPHPExcel->getActiveSheet()
            			->setCellValue('E'.$startIndex, $b_salesToday." €"); 
            $objPHPExcel->getActiveSheet()
           				 ->setCellValue('F'.$startIndex, $totSales." €");
           	$objPHPExcel->getActiveSheet()->getStyle('F'.$startIndex)->getFont()->setBold(true);   

  	$startIndex++;  
}

	  ob_end_clean();

     $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header("Content-Disposition: attachment;filename=sale-per-parent.xlsx");
	header('Cache-Control: max-age=0');
	header("Content-Type: application/download");
	$objWriter->save('php://output');
  die;

