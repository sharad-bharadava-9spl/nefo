<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/view.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';
	
	session_start();
	$accessLevel = '1';
	
	// Authenticate & authorize
	authorizeUser($accessLevel);
	
	// Query to look up users
	$selectUsers = "SELECT u.user_id, u.memberno, u.first_name, u.last_name, u.registeredSince, u.dni, u.gender, u.day, u.month, u.year, u.doorAccess, u.paidUntil, u.userGroup, ug.groupName, ug.groupDesc, u.form1, u.form2, u.credit, u.usageType, u.creditEligible, u.dniscan, u.dniext1, u.family FROM users u, usergroups ug WHERE u.userGroup = ug.userGroup AND u.userGroup <> 4 ORDER by u.last_name ASC";
		try
		{
			$results = $pdo3->prepare("$selectUsers");
			$results->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		
	
		
	$memberScript = <<<EOD
	
	    $(document).ready(function() {
		    
		    
			$("#xllink").click(function(){

			  $("#mainTable").table2excel({
			    // exclude CSS class
			    exclude: ".noExl",
			    name: "Socios",
			    filename: "Socios" //do not include extension
		
			  });
		
			});
		    
		    
		    
			$('#cloneTable').width($('#mainTable').width());
			
			$.tablesorter.addParser({
			  id: 'dates',
			  is: function(s) { return false },
			  format: function(s) {
			    var dateArray = s.split('-');
			    return dateArray[2].substring(0,4) + dateArray[1] + dateArray[0];
			  },
			  type: 'numeric'
			});
			
			
			$('#mainTable').tablesorter({
				usNumberFormat: true,
				headers: {
					3: {
						sorter: "currency"
					},
					4: {
						sorter: "currency"
					},
					5: {
						sorter: "currency"
					}
				}
			}); 
		
		});
		
		$(window).resize(function() {
			$('#cloneTable').width($('#mainTable').width());
		});
		
EOD;


	pageStart($lang['global-donations'], NULL, $memberScript, "pmembership", NULL, "SALES PER FAMILY", $_SESSION['successMessage'], $_SESSION['errorMessage']);
?>
	 <table class='default' id='cloneTable'>
      <tr class='nonhover'>
       <td colspan='13' style='border-bottom: 0;'>
         <a href="javascript:void(0);" onClick="loadExcel();" > <img src="images/excel.png" style='margin: 0 0 -5px 8px;'/></a>
       </td>
      </tr>
     </table>
<br />
	 <table class='default' id='mainTable'>
	  <thead>	
	   <tr style='cursor: pointer;'>
	    <th><?php echo $lang['global-name']; ?></th>
	    <th><?php echo $lang['member-lastnames']; ?></th>
	    <th>Group</th>
	    <th>Bocadillo</th>
	    <th>SnackShack</th>
	    <th>Total</th>
	   </tr>
	  </thead>
	  <tbody>
	  
	  <?php

		while ($user = $results->fetch()) {
	
	$family = $user['family'];
	
	$emailQuery = "SELECT user_id FROM users WHERE family = $family";
		try
		{
			$results2 = $pdo3->prepare("$emailQuery");
			$results2->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		
	$familyIDs = '';
		
		while ($rowU = $results2->fetch()) {
		
		$uid = $rowU['user_id'];
		
		$familyIDs .= "$uid, ";
		
	}
	
	$familyTrimmed = substr($familyIDs, 0, -2);
		
	// Look up bocadillo sales
	$selectSales = "SELECT SUM(amount) from sales WHERE userid IN ($familyTrimmed)";
		try
		{
			$result = $pdo3->prepare("$selectSales");
			$result->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		$row = $result->fetch();
		$salesToday = $row['SUM(amount)'];
	
	// Look up snackshack sales
	$selectb_sales = "SELECT SUM(amount) from b_sales WHERE userid IN ($familyTrimmed)";
		try
		{
			$result = $pdo3->prepare("$selectb_sales");
			$result->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	
		$row = $result->fetch();
		$b_salesToday = $row['SUM(amount)'];
		
	$totSales = $salesToday + $b_salesToday;
	
	
	echo sprintf("
  	  <tr>
  	   <td class='clickableRow' href='profile.php?user_id=%d'>%s</td>
  	   <td class='clickableRow' href='profile.php?user_id=%d'>%s</td>
  	   <td class='clickableRow' href='profile.php?user_id=%d'>%s</td>
  	   <td class='clickableRow right' href='profile.php?user_id=%d'>%0.2f &euro;</td>
  	   <td class='clickableRow right' href='profile.php?user_id=%d'>%0.2f &euro;</td>
  	   <td class='clickableRow right' href='profile.php?user_id=%d'><strong>%0.2f &euro;</strong></td></tr>",
	  $user['user_id'], $user['first_name'], $user['user_id'], $user['last_name'], $user['user_id'], $user['groupName'], $user['user_id'], $salesToday, $user['user_id'], $b_salesToday, $user['user_id'], $totSales);
  	  
}

	  
?>

	 </tbody>
	 </table>

<?php  displayFooter(); ?>
<script type="text/javascript">
		 function loadExcel(){
 			$("#load").show();
       		window.location.href = 'sale-per-parent-report.php';
       		    setTimeout(function () {
			        $("#load").hide();
			    }, 5000);   
       }
</script>