<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';
	
	$accessLevel = '3';

	//ini_set("display_errors", 'on');
	// Authenticate & authorize
	authorizeUser($accessLevel);
	// maxmum upload file size
	$max_file = 20; // video size
	$max_file2 = 20; // preview image size

	$allowed_image_types = array('image/pjpeg'=>"jpg",'image/jpeg'=>"jpg",'image/jpg'=>"jpg",'image/pjpeg'=>"jpeg",'image/jpeg'=>"jpeg",'image/jpg'=>"jpeg",'image/png'=>"png",'image/x-png'=>"png",'image/gif'=>"gif");

	$allowed_video_types = array('video/mp4'=>'mp4');

	$video_upload_dir = "videos";     // The directory for the video to be saved in
	if(!is_dir($video_upload_dir)){
	  mkdir($video_upload_dir, 0777);
	}
	$video_upload_dir = "videos"; 
	$video_upload_path = $video_upload_dir."/";      
	$video_prefix = "help_video_";      
	$video_name = $video_prefix.strtotime(date('Y-m-d H:i:s'));
	$video_location = $video_upload_path.$video_name.$_SESSION['video_file_ext']; 	

	$preview_upload_dir = "videos/preview_images";     // The directory for the preview image to be saved in
	if(!is_dir($preview_upload_dir)){
	  mkdir($preview_upload_dir, 0777);
	}
	$preview_upload_dir = "videos/preview_images"; 
	$preview_upload_path = $preview_upload_dir."/";      
	$preview_prefix = "video_preview_";      
	$preview_name = $preview_prefix.strtotime(date('Y-m-d H:i:s'));
	$preview_location = $preview_upload_path.$preview_name.$_SESSION['preview_file_ext']; 
	// Did this page re-submit with a form? If so, check & store details
	if (isset($_POST['video_id'])) {
		
	    $video_title = str_replace("'","\'",str_replace('%', '&#37;', trim($_POST['video_title']))); 
		$video_desc = str_replace("'","\'",str_replace('%', '&#37;', trim($_POST['video_desc'])));
		$tag = str_replace("'","\'",str_replace('%', '&#37;', trim($_POST['tag_id'])));
		$video_duration = str_replace("'","\'",str_replace('%', '&#37;', trim($_POST['video_duration'])));
		$video_status = str_replace("'","\'",str_replace('%', '&#37;', trim($_POST['video_status'])));
		$last_video_path = $_POST['last_video_path'];
		$last_preview_path = $_POST['last_preview_path'];
		$video_id = $_POST['video_id'];

		if(empty($tag) || $tag == ''){
		    $_SESSION['errorMessage'].= "Please choose video tags from the list only !";
            header("Location: edit-video.php?videoid=".$video_id);
            die;
		}
		// video upload
      	if (!empty($_FILES['video_file']['name'])) { 
          //Get the file information

	            $video_name = $_FILES['video_file']['name'];
	            $video_tmp = $_FILES['video_file']['tmp_name'];
	            $video_size = $_FILES['video_file']['size'];
	            $video_type = $_FILES['video_file']['type'];
	            $filename = basename($_FILES['video_file']['name']);
	            $file_ext = strtolower(substr($filename, strrpos($filename, '.') + 1));
	            $_SESSION['extension'] = $file_ext;
	            
	            //Only process if the file is a JPG, PNG or GIF and below the allowed limit
	            if((!empty($_FILES["video_file"])) && ($_FILES['video_file']['error'] == 0)) {
	              
	              foreach ($allowed_video_types as $mime_type => $ext) {
	                //loop through the specified image types and if they match the extension then break out
	                //everything is ok so go and check file size
	                if($file_ext==$ext && $video_type==$mime_type){
	                  $error = "";
	                  break;
	                }
	              }
	              //check if the file size is above the allowed limit
	              if ($video_size > ($max_file*1048576)) {
	                $_SESSION['errorMessage'].= "video must be under ".$max_file."MB in size";
	                header("Location: edit-video.php?videoid=".$video_id);
	                die;
	              }
	              
	            }

	            //Everything is ok, so we can upload the image.
	            if (strlen($error)==0){
	              
	              if (isset($_FILES['video_file']['name'])){
	                //this file could now has an unknown file extension (we hope it's one of the ones set above!)
	                if ($_SESSION['video_file_ext'] == "") {
	                  $video_location = $video_location.".".$file_ext;
	                  //$thumb_image_location = $thumb_image_location.".".$file_ext;
	                }     
	                
	                	//put the file ext in the session so we know what file to look for once its uploaded
	               		 $_SESSION['video_file_ext']=".".$file_ext;
	              
		                move_uploaded_file($video_tmp, $video_location); 
		                chmod($video_location, 0777);
		                unlink($last_video_path);
	              }
	              
	            }

          }else{
          	 $video_location = $last_video_path;
          }
          // upload preview image
 			if (!empty($_FILES['video_preview']['name'])) { 
	          //Get the file information

		            $preview_name = $_FILES['video_preview']['name'];
		            $preview_tmp = $_FILES['video_preview']['tmp_name'];
		            $preview_size = $_FILES['video_preview']['size'];
		            $preview_type = $_FILES['video_preview']['type'];
		            $preview_filename = basename($_FILES['video_preview']['name']);
		            $preview_file_ext = strtolower(substr($preview_filename, strrpos($preview_filename, '.') + 1));
		            //$_SESSION['extension'] = $file_ext;
		            
		            //Only process if the file is a JPG, PNG or GIF and below the allowed limit
		            if((!empty($_FILES["video_preview"])) && ($_FILES['video_preview']['error'] == 0)) {
		              
		              foreach ($allowed_image_types as $mime_type => $ext) {
		                //loop through the specified image types and if they match the extension then break out
		                //everything is ok so go and check file size
		                if($preview_file_ext==$ext && $preview_type==$mime_type){
		                  $error = "";
		                  break;
		                }
		              }
		              //check if the file size is above the allowed limit
		              if ($preview_size > ($max_file2*1048576)) {
		                $_SESSION['errorMessage'].= "Video preview image must be under ".$max_file2."MB in size";
		                header("Location: edit-video.php?videoid=".$video_id);
		                die;
		              }
		              
		            }

		            //Everything is ok, so we can upload the image.
		            if (strlen($error)==0){
		              
		              if (isset($_FILES['video_preview']['name'])){
		                //this file could now has an unknown file extension (we hope it's one of the ones set above!)
		                if ($_SESSION['preview_file_ext'] == "") {
		                  $preview_location = $preview_location.".".$preview_file_ext;
		                  //$thumb_image_location = $thumb_image_location.".".$file_ext;
		                }     
		                
		                	//put the file ext in the session so we know what file to look for once its uploaded
		               		 $_SESSION['preview_file_ext']=".".$preview_file_ext;
		              
			                move_uploaded_file($preview_tmp, $preview_location); 
			                chmod($preview_location, 0777);
			                unlink($last_preview_path);
		              }
		              
		            }

          }else{
          		$preview_location = $last_preview_path;
          }
         $updateTime = date("Y-m-d H:i:s");

		 $updateVideo = "UPDATE help_videos SET video_title = '$video_title', video_status = '$video_status', description = '$video_desc', tags = '$tag', video_path = '$video_location', preview_path = '$preview_location',video_duration = '$video_duration', created_at = '$updateTime' WHERE id=$video_id";  

				try
				{
					$result = $pdo3->prepare("$updateVideo")->execute();
				}
				catch (PDOException $e)
				{
						$error = 'Error fetching user: ' . $e->getMessage();
						echo $error;
						exit();
				}	

				$_SESSION['successMessage'] = "Video updated successfully!";
				header("Location: edit-video.php?videoid=".$video_id);
				exit();
	}
	
	/***** FORM SUBMIT END *****/