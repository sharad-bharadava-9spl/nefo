<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/view.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';
	
	session_start();
	$accessLevel = '3';
	$videoid = $_GET['videoid'];
		if(empty($videoid) || $videoid == ''){
			header("Location:help-section.php");
			exit();
		}
	// Authenticate & authorize
	authorizeUser($accessLevel);

	$validationScript = <<<EOD
    $(document).ready(function() {
    	    
	  $('#registerForm').validate({
		  rules: {
			  video_file: {
				  extension: "mp4",
				  /*filesize: 8388608*/
			  },
			  video_preview:{
			  	 extension: "jpg|jpeg|png"
			  }
    	}, // end rules
		  errorPlacement: function(error, element) {
			 if ( element.is(":radio") || element.is(":checkbox")){
				 error.appendTo(element.parent());
			} else {
				return true;
			}
		}
		 
    	 
	  }); // end validate


  }); // end ready
EOD;
	
   //  query to look up issues
	$selectTags = "SELECT id,tag FROM video_tags order by id ASC"; 
		try
		{
			$result_tag = $pdo3->prepare("$selectTags");
			$result_tag->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
	while($rowTag = $result_tag->fetch()){
		$tag_arr[$rowTag['id']] =  $rowTag['tag'];
	}


	pageStart("Edit Video", NULL, $validationScript, "pprofile", NULL, "Edit Video", $_SESSION['successMessage'], $_SESSION['errorMessage']);


		// Query to look up videos
		$selectVideos = "SELECT * FROM  help_videos WHERE id = $videoid";
		try
		{
			$results = $pdo3->prepare("$selectVideos");
			$results->execute();
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
		$row = $results->fetch();
			$video_title = $row['video_title'];
			$description = $row['description'];
			$tags = $row['tags'];
			$video_path = $row['video_path'];
			$preview_path = $row['preview_path'];
			$video_duration = $row['video_duration'];
			$video_status = $row['video_status'];

			//get tag name
			if(empty($tags) || $tags == ''){
		   			$tags = -1;
		   		}

		   		 $selectTagsId = "SELECT tag from video_tags WHERE id IN ($tags)";
		   				try
						{
							$tag_id_results = $pdo3->prepare("$selectTagsId");
							$tag_id_results->execute();
						}
						catch (PDOException $e)
						{
								$error = 'Error fetching user: ' . $e->getMessage();
								echo $error;
								exit();
						}
						
						while($tagIdRow = $tag_id_results->fetch()){
							$tag_id_arr[] = $tagIdRow['tag'];
						}


						$tag_names = implode(",", $tag_id_arr);
?>
<center>
	<a href='help-section.php' class='cta'>Help Center</a>
	<a href='video-tags.php' class='cta'>Video Tags</a>
</center>
<form id="registerForm" action="edit-video-process.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="video_id" value="<?php echo $videoid ?>">
 <div class="overview">
	<table class='profileTable'>
		 <tr>
		  <td><strong>Video Title</strong></td>
		  <td><input type="text" name="video_title"  value="<?php echo $video_title; ?>" required /></td>
		 </tr>
		 <tr>
		  <td><strong>Video status</strong></td>
		  <td>
		  	<input type="radio" name="video_status"  value="1" <?php if($video_status == 1){ echo 'checked';  } ?> />New
		  	<input type="radio" name="video_status"  value="0" <?php if($video_status == 0){ echo 'checked';  } ?>/>Old
		  </td>
		 </tr>
		 <tr>
		  <td><strong>Video Description</strong></td>
		  <td>
		    <textarea name="video_desc" required="" rows="4" cols="50"><?php echo $description ?></textarea>
		  </td>
		 </tr>
		 <tr>
		 	<td>
		 		<strong>Add Tags</strong>
		 	</td>
		 	<td>
	 			<input type="text" name="tag" id="tagselect" value="<?php echo $tag_names ?>"  class="multi_tags" placeholder="add multiple tags" required="">
			  	<input type="hidden" name="tag_id" id="tag_ids" value="<?php echo $tags; ?>">
		 	</td>
		 </tr>
		 <tr>
		 	<td>
		 		<strong>Add Video File</strong>
		 	</td>
		 	<td><input type="file" id="video_input" name='video_file' accept="video/mp4,video/x-m4v"><br><br>
		 		<input type="hidden" name="last_video_path" value="<?php echo $video_path; ?>">
		 		<input type="hidden" name="video_duration" id="video_duration_time" value="<?php echo $video_duration ?>">
		 		<video width="400" controls>
				 <source src="<?php echo $video_path; ?>" type="video/mp4">
				  Your browser does not support HTML5 video.
				 </video>
		 	</td>
		 </tr>		 
		 <tr>
		 	<td>
		 		<strong>Add Video Preview image</strong>
		 	</td>
		 	<td><input type="file"  name='video_preview' accept="image/*"><br><br>
		 		<input type="hidden" name="last_preview_path" value="<?php echo $preview_path; ?>">
		 		<img src="<?php echo $preview_path ?>" width="400">
		 	</td>
		 </tr>
		</table>
		
	<button class='oneClick' name='save_video' type="submit"><?php echo $lang['global-savechanges']; ?></button>
</div>

<?php displayFooter(); ?>
<script type="text/javascript">
	document.getElementById('video_input').onchange = setFileInfo;

	function setFileInfo() {
	  var files = this.files;
	  myVideos = files[0];
	  var video = document.createElement('video');
	  video.preload = 'metadata';

	  video.onloadedmetadata = function() {
	    window.URL.revokeObjectURL(video.src);
	    var duration = video.duration;
	    myVideos.duration = duration;
	    updateInfos();
	  }

	  video.src = URL.createObjectURL(files[0]);;
	}


	function updateInfos() {
	    var duration_time = myVideos.duration;
	    $("#video_duration_time").val(duration_time);
	    console.log(duration_time);
	}
		 // user multiselect autocomplete  
	 var tag_arr = <?php echo json_encode($tag_arr)  ?>;
	
	 	 var tag_name =[];
	  	for(var i in tag_arr){
	  		tag_name.push(tag_arr[i]);
	  	}
	
	$( function() {
		
		function split( val ) {
			return val.split( /,\s*/ );
		}
		function extractLast( term ) {
			return split( term ).pop();
		}

		$( ".multi_tags" )
			// don't navigate away from the field on tab when selecting an item
			.on( "keydown", function( event ) {
				if ( event.keyCode === $.ui.keyCode.TAB &&
						$( this ).autocomplete( "instance" ).menu.active ) {
					event.preventDefault();
				}
			})
			.autocomplete({
				minLength: 0,
				source: function( request, response ) {
					// delegate back to autocomplete, but extract the last term
					response( $.ui.autocomplete.filter(
						tag_name, extractLast( request.term ) ) );
				},
				focus: function(event, ui) {
					// prevent value inserted on focus
					return false;
				},
				select: function( event, ui ) {
					var terms = split( this.value );
					// remove the current input
					terms.pop();
					// add the selected item
					terms.push( ui.item.value );
					// add placeholder to get the comma-and-space at the end
					terms.push( "" );
					this.value = terms.join( ", " );
				 
					var tag_ids = [];	
					Object.keys(tag_arr).forEach(function(k){
						for(var i in terms){
							if(terms[i] != '' && terms[i] == tag_arr[k]){
								tag_ids.push(k);
							}
						}
					});
					
					$("#tag_ids").val(tag_ids.join());
					return false;
				},
				change: function( event, ui ) {
					var terms = split( this.value );
					console.log(terms);
					// remove the current input
					terms.pop();
					
					// add placeholder to get the comma-and-space at the end
					terms.push( "" );
					this.value = terms.join( ", " );
					
					var tag_ids = [];	
					Object.keys(tag_arr).forEach(function(k){
						for(var i in terms){
							if(terms[i] != '' && terms[i] == tag_arr[k]){
								tag_ids.push(k);
							}
						}
					});
					$("#tag_ids").val(tag_ids.join());
					return false;
				}
			});
	} );
</script>