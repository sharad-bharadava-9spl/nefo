<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/view.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';
	session_start();
	$accessLevel = '3';
	
	
	
	$memberScript = <<<EOD
	
	    $(document).ready(function() {
		    
		    
			$("#xllink").click(function(){

			  $("#mainTable").table2excel({
			    // exclude CSS class
			    exclude: ".noExl",
			    name: "Help-videos",
			    filename: "Help-videos" //do not include extension
		
			  });
		
			});
		    
		    
		    
			$('#cloneTable').width($('#mainTable').width());
			
			$.tablesorter.addParser({
			  id: 'dates',
			  is: function(s) { return false },
			  format: function(s) {
			    var dateArray = s.split('-');
			    return dateArray[2].substring(0,4) + dateArray[1] + dateArray[0];
			  },
			  type: 'numeric'
			});
			
			
			$('#mainTable').tablesorter({
				usNumberFormat: true,
				headers: {
					3: {
						sorter: "dates"
					}
				}
			}); 

		});
		
		$(window).resize(function() {
			$('#cloneTable').width($('#mainTable').width());
		});

	function delete_element(delete_id){
      	 if(confirm('Are you sure to delete this video ?')){
      	 	 window.location = "help-section.php?did="+delete_id;
      	 }
      }
		
EOD;
// delete videos

	if(isset($_GET['did'])){
		// delete department
		$id= $_GET['did'];
		$deleteVideo = "DELETE FROM help_videos where id = $id";
			try
			{
				$results = $pdo3->prepare("$deleteVideo");
				$results->execute();
			}
			catch (PDOException $e)
			{
					$error = 'Error fetching user: ' . $e->getMessage();
					echo $error;
					exit();
			}
			$_SESSION['successMessage'] = "Video deleted successfully!";
			header("location: help-section.php");
			exit();
	}

	pageStart("Help Center", NULL, $memberScript, "pmembership", NULL, "Help Center", $_SESSION['successMessage'], $_SESSION['errorMessage']);
?>

<center>
	<a href='new-video.php' class='cta'>Add New Video</a>
	<a href='video-tags.php' class='cta'>Tags</a>
	<a href='feedback.php' class='cta'>Feedback</a>
</center>

	 <table class='default' id='cloneTable'>
      <tr class='nonhover'>
       <td colspan='13' style='border-bottom: 0;'>
         <a href="#" id="xllink" onClick="$('#mainTable').tableExport({type:'excel',escape:'false'});"><img src="images/excel.png" style='margin: 0 0 -5px 8px;'/></a>
       </td>
      </tr>
     </table>
<br />
<?php 
     // select videos
	$selectVideos = "SELECT * from help_videos order by id desc";
		try
		{
			$result = $pdo3->prepare("$selectVideos");
			$result->execute();
			
		}
		catch (PDOException $e)
		{
				$error = 'Error fetching user: ' . $e->getMessage();
				echo $error;
				exit();
		}
 ?>

	 <table class='default' id='mainTable'>
		  <thead>	
		   <tr style='cursor: pointer;'>
		    <th>Video Title</th>
		    <th>Description</th>
		    <th>Tags</th>
		    <th>Status</th>
		    <th>Created</th>
		    <th>Actions</th>
		   </tr>
		  </thead>
		  <tbody>
		<?php
		$i= 0;
		   while($video = $result->fetch()){
		   		$videoid = $video['id'];
		   		$video_title = $video['video_title'];
		   		$description = $video['description'];
		   		$tag_ids = $video['tags'];
		   		$created = $video['created_at'];
		   		$status = $video['video_status'];
		   		$video_status = '';
		   		if($status == 1){
		   			$video_status = 'New';
		   		}


		   			if ($description != '') {
							$commentRead = "
							                <img src='images/description.png' id='comment$videoid' /><div id='helpBox$videoid' class='helpBox'><strong>{$lang['extracts-description']}:</strong><br />{$description}</div>
							                <script>
							                  	$('#comment$videoid').on({
											 		'mouseover' : function() {
													 	$('#helpBox$videoid').css('display', 'block');
											  		},
											  		'mouseout' : function() {
													 	$('#helpBox$videoid').css('display', 'none');
												  	}
											  	});
											</script>
							                ";
						} else {
							
							$commentRead = "";
							
						}
		   		// get tag names
		   		if(empty($tag_ids) || $tag_ids == ''){
		   			$tag_ids = -1;
		   		}

		   		$selectTags = "SELECT tag from video_tags WHERE id IN ($tag_ids)";
		   				try
						{
							$tag_results = $pdo3->prepare("$selectTags");
							$tag_results->execute();
						}
						catch (PDOException $e)
						{
								$error = 'Error fetching user: ' . $e->getMessage();
								echo $error;
								exit();
						}
						$t=0;
						while($tagRow = $tag_results->fetch()){
							$tag_arr[$i][$t] = $tagRow['tag'];
							$t++;
						}
						$tag_names = implode(",", $tag_arr[$i]);


		   		$video_row =	sprintf("
			  	  <tr>
			  	   <td class='clickableRow' href='edit-video.php?videoid=%d'>%s</td>
			  	   <td class='relative clickableRow' style='padding: 11px 6px 11px 0;text-align: center;' href='edit-video.php?videoid=%d'>$commentRead</td>
			  	   <td class='clickableRow' href='edit-video.php?videoid=%d'>%s</td>
			  	   <td class='clickableRow' href='edit-video.php?videoid=%d'>%s</td>
			  	   <td class='clickableRow' href='edit-video.php?videoid=%d'>%s</td>
			  	   <td style='text-align: center;'><a href='edit-video.php?videoid=%d'><img src='images/edit.png' height='15' title='Editar' /></a>&nbsp;&nbsp;<a href='javascript:void(0)' onClick='delete_element(%d)' ><img src='images/delete.png' height='15' title='Delete Video' /></a></td>
				  </tr>",
				  $videoid, $video_title, $videoid, $videoid, $tag_names, $videoid, $video_status, $videoid, $created, $videoid, $videoid
				  );
				  $i++;
				  echo $video_row;
		   }
        ?>
		  </tbody>
	 </table>
<?php  displayFooter();