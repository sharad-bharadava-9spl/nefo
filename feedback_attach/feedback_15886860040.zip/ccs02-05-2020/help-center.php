<?php
	
	require_once 'cOnfig/connection.php';
	require_once 'cOnfig/view.php';
	require_once 'cOnfig/authenticate.php';
	require_once 'cOnfig/languages/common.php';
	//ini_set("display_errors", "on");
	
	session_start();
	$accessLevel = '3';
	
	// Authenticate & authorize
	authorizeUser($accessLevel);
	
	getSettings();	
	$validationScript = <<<EOD
    $(document).ready(function() {
      $("#feedback_form").validate({
      		rules:{
      			reason:{required: true },
      			issue:{required: true },
      			message:{required: true },
      		}
      	});
  }); // end ready
EOD;

	pageStart('Help Center', NULL, $validationScript, "help-center", NULL, 'Help Center', $_SESSION['successMessage'], $_SESSION['errorMessage']);


?>
	<div id="help-tabs">
	  <ul>
	    <li><a href="#feedback">Feedback</a></li>
	    <li><a href="#faq">FAQ</a></li>
	    <li><a href="#video-tutorials">Video tutorials</a></li>
	    <li><a href="#updates">Updates</a></li>
	  </ul>
	  <div id="feedback">
	  	<?php  include "help-feedback-form.php";  ?>
	  </div>
	  <div id="faq">
	    <?php include "help-faq.php"; ?>
	  </div>
	  <div id="video-tutorials">
	    <?php include "video-tutorials.php" ?>
	  </div>
	  <div id="updates">
	    <p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
	  </div>
	</div>
	<?php  displayFooter(); ?>
	  <script>
		  $( function() {
		    $( "#help-tabs" ).tabs();
		  } );
  	</script>