<?php  $maximum_files = 5;  ?>
<div id="mainbox-no-width" style="display: block;">
	 <div id="mainboxheader">Feedback</div>
	 <form id="feedback_form" action="help-feedback-post.php" method="POST" enctype="multipart/form-data">
		 <div class="boxcontent" style="margin-left: 36px;">
		   <span class="smallgreen">MOTIVO</span>
		   <select name="reason" required="" class="defaultinput" style="width: 42%; height: 38px;">
		   	<option value="">Select Reason</option>
		   	<option value="Bug report">Bug report</option>
		   	<option value="Testimonial">Testimonial</option>
		   	<option value="Just saying 'hi'">Just saying 'hi'</option>
		   	<option value="Interface issue">Interface issue</option>
		   </select>&nbsp;&nbsp;
		   <span class="smallgreen">Issue</span><input type="text" name="issue" class="defaultinput" style="width: 42%;" placeholder="start typing here..."  required=""><br>
		   <div class='feedbck_txtareara'>
		 		<span class="smallgreen" style="margin-top: 16px;display: block;float: left;">Message</span><textarea name="message" style="width: 89%; height: 150px;" class="defaultinput" placeholder="type here the content of your message." required=""></textarea>
		 	</div>
		 	<span class="smallgreen">Attachments :</span>(you can select maximum <?php echo $maximum_files; ?> files to upload)&nbsp;&nbsp;<input type="file" name="attach_files[]" multiple>
		 	<input type="hidden" name="max_files" value="<?php echo $maximum_files; ?>">
		</div>
		<button type="submit" name="feedback_sub" class='cta2' style="margin-left: 83%"><?php echo $lang['submit']; ?></button>
	</form>
</div>