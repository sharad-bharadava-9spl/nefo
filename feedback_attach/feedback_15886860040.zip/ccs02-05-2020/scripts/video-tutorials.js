$(document).ready(function(){
		$("#filter_label").click(function(){
			$('#label_section').slideToggle('fast');
			$(this).toggleClass("tag_open");
			if($(this).hasClass("tag_open")){
				$("#open_arrow").show();
				$("#close_arrow").hide();
				$("#close_filter").hide();
				$("#open_filter").show();
			}else{
				$("#close_arrow").show();
				$("#open_arrow").hide();
				$("#close_filter").show();
				$("#open_filter").hide();
			}
		});
	});

	$(function(){
	     function stopVideo(video_id){
	     	 var video = document.getElementById(video_id);
	          video.pause();
	          video.currentTime = 0;
	     }
		var appendthis =  ("<div class='modal-overlay'></div>");

		  $(document).on('click','a[data-modal-id]',function(e) {
		    e.preventDefault();
		    $("body").append(appendthis);
		    $(".modal-overlay").fadeTo(500, 0.7);
		    //$(".js-modalbox").fadeIn(500);
		    var modalBox = $(this).attr('data-modal-id');
		    $('#'+modalBox).fadeIn($(this).data());
		   
		  });  
		  
		  
		$(document).on("click",".js-modal-close",function() {
		  $(".modal-box, .modal-overlay").fadeOut(500, function() {
		    $(".modal-overlay").remove();
		  });
		  var popup_id = $(this).parent().attr('id');
		  var video_id_arr = popup_id.split('popup');
		  var video_id = video_id_arr[1];
		  var html_video_id = "vidid"+video_id;
		  stopVideo(html_video_id);
		  //var viseo_id = $()
		});
		 
		$(window).resize(function() {
		  $(".modal-box").css({
		  //	top: $(".modal-box").outerHeight() / 2,
		    top: ($(window).height() - $(".modal-box").outerHeight()) / 2,
		    left: ($(window).width() - $(".modal-box").outerWidth()) / 2
		  });
		});
		 
		//$(window).resize();
	 
	});
	$(".tag_item span").click(function(){
		var this_id = $(this).attr('id');
		var tag_id_val = this_id.split('tag_');
        var tag_id = tag_id_val[1];
        var selected_ids = $("#filter_tag_ids").val();
        var tag_id_string = ''; 
        //tag_id_arr.push(tag_id);
		if(!$(this).hasClass('tag_active')){
			if(selected_ids == ''){
        	  tag_id_string = '';
        	}else{
				tag_id_string = selected_ids+'|';
			}
	        $(this).addClass('tag_active');
	        var this_name = $(this).text();
	        $(".selected_tags").append("<span id='select_"+this_id+"' class='usergrouptext tag_active'>"+this_name+"</span>");
	        tag_id_string += tag_id;
	         $("#filter_tag_ids").val(tag_id_string);
    	}else{
    	   $(this).removeClass('tag_active');
	        var this_name = $(this).text();
	        $("#select_"+this_id).remove();
	        var new_id_string = selected_ids.replace(tag_id,"");
            var new_id_arr = new_id_string.split('|');
            new_id_arr = new_id_arr.filter(Boolean);
	         $("#filter_tag_ids").val(new_id_arr.join('|'));
    	}
    	
    	  // search filter
    	   $(".video_section").hide();
    	    $('#loader_img').show();
	    	var search_val = $("input[name='video_search']").val();
		 	var filter_tags = $("#filter_tag_ids").val();
		 	var page_no = 1;
		 	var records_per_page = $("#total_records_per_page").val();
		 	$.ajax({
                  type:"post",
                  url:"video-search-filter.php",
                  datatype:"text",
                  data: {'video_text': search_val,"filter_tags": filter_tags, "page": page_no,"records":records_per_page},
                  cache: false,
                  success:function(data)
                  {
                  	  setTimeout(function(){
	                  	   	$('#loader_img').hide();
	                      	$(".video_section").show().html(data);
                  	 },1000);

                  }
            });   
	});

	// serach filters
	$("#filter_sub").click(function(e){
		e.preventDefault();
			$('#loader_img').show();
			$(".video_section").hide();
		 	var search_val = $("input[name='video_search']").val();
		 	var filter_tags = $("#filter_tag_ids").val();
		 	var page_no = 1;
		 	var records_per_page = $("#total_records_per_page").val();
		 	$.ajax({
                  type:"post",
                  url:"video-search-filter.php",
                  datatype:"text",
                  data: {'video_text': search_val,"filter_tags": filter_tags,"page":page_no,"records": records_per_page},
                  cache: false,
                  success:function(data)
                  {
                  	  setTimeout(function(){ 
	                  	  $('#loader_img').hide();
	                      $(".video_section").show().html(data);
                  	}, 1000);

                  }
            });
	});
		 	//alert(filter_tags);
		
			// serach filters
	$(document).on('click', '.pagination_nav li a', function(e){
		e.preventDefault();
		  var page_no = $(this).data('page');
		  if(page_no != '' && page_no != null){
				$('#loader_img').show();
				$(".video_section").hide();
				var records_per_page = $("#total_records_per_page").val();
				$("#page_no").val(page_no);
			 	var search_val = $("input[name='video_search']").val();
			 	var filter_tags = $("#filter_tag_ids").val();
			 	$.ajax({
	                  type:"post",
	                  url:"video-search-filter.php",
	                  datatype:"text",
	                  data: {'video_text': search_val,"filter_tags": filter_tags, "page":page_no,"records":records_per_page},
	                  cache: false,
	                  success:function(data)
	                  {
	                  	  setTimeout(function(){ 
		                  	  $('#loader_img').hide();
		                      $(".video_section").show().html(data);
	                  	}, 1000);

	                  }
	            });
		 }
	});